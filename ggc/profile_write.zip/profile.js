/*
function toggleMenu(){
	var sideBar=$("#side-bar");
	if(sideBar.hasClass("open")){
		sideBar.animate({width:'280px', 'padding-left':'10px', 'padding-right':'10px'},450);
	}else{
		sideBar.animate({width:'0px', 'padding-left':'0px', 'padding-right':'0px'},450);
	}
	sideBar.toggleClass('open');
}

var sideBars=[
	{text:'홈', link:'index.html'},
	{text:'로그인', link:'login.html'},
	{text:'회원가입', link:'register.html'},
	{text:'내 정보', link:'info.html'},
	{text:'둘러보기', link:'find.html'},
	{text:'등록하기', link:'upload.html'}
];

var side_bar=new Vue({
	el:'#side-bar',
	data:{
		sideBar:sideBars
	}
});
*/

$(window).scroll(function(event){ 
	var scrollLocation=$('html').scrollTop();
	$('header').css('background-color','rgba(28, 28, 28, '+Math.min(1, scrollLocation*0.003)+')');
});

$("#profile-img").animate({
  	opacity: 1
},300,function(){
	$("#profile-header").animate({
  		opacity: 1
	},200,function(){
		$("#profile-main").animate({
  			opacity: 1
		},300);
	});
});

$(document).ready(function(){
	$('#card-input').on('keyup', function(){
		if($('#card-input').val().length>100){
			alert("100글자를 초과할 수 없습니다.");
			$('#card-input').val($(this).val().substring(0, 100));
		}
	});
});

var area_detail=new Vue({
	el:'.newcard-form',
	data:{
		seoul:[
			{val:'', name:'강동'},
			{val:'', name:'송파'},
			{val:'', name:'강남'},
			{val:'', name:'서초'},
			{val:'', name:'관악'},
			{val:'', name:'동작'},
			{val:'', name:'금천'},
			{val:'', name:'구로'},
			{val:'', name:'양천'},
			{val:'', name:'영등포'},
			{val:'', name:'강서'},
			{val:'', name:'마포'},
			{val:'', name:'용산'},
			{val:'', name:'성동'},
			{val:'', name:'광진'},
			{val:'', name:'동대문'},
			{val:'', name:'중랑'},
			{val:'', name:'노원'},
			{val:'', name:'도봉'},
			{val:'', name:'강북'},
			{val:'', name:'성북'},
			{val:'', name:'종로'},
			{val:'', name:'중구'},
			{val:'', name:'서대문'},
			{val:'', name:'은평'}
		],
		pusan:[
			{val:'', name:'강서'},
			{val:'', name:'사상'},
			{val:'', name:'사하'},
			{val:'', name:'서구'},
			{val:'', name:'중구'},
			{val:'', name:'동구'},
			{val:'', name:'영도'},
			{val:'', name:'남구'},
			{val:'', name:'부산진'},
			{val:'', name:'북구'},
			{val:'', name:'동래'},
			{val:'', name:'연제'},
			{val:'', name:'수영'},
			{val:'', name:'해운대'},
			{val:'', name:'금정'},
			{val:'', name:'기장'}
		],
		daegu:[
			{val:'', name:'동구'},
			{val:'', name:'북구'},
			{val:'', name:'수성'},
			{val:'', name:'중구'},
			{val:'', name:'남구'},
			{val:'', name:'서구'},
			{val:'', name:'달서'},
			{val:'', name:'달성'}
		],
		incheon:[
			{val:'', name:'강화'},
			{val:'', name:'서구'},
			{val:'', name:'중구'},
			{val:'', name:'동구'},
			{val:'', name:'미추홀'},
			{val:'', name:'연수'},
			{val:'', name:'남동'},
			{val:'', name:'부평'},
			{val:'', name:'계양'},
			{val:'', name:'옹진'}
		],
		gwangju:[
			{val:'', name:'광산'},
			{val:'', name:'서구'},
			{val:'', name:'남구'},
			{val:'', name:'동구'},
			{val:'', name:'북구'}
		],
		daejeon:[
			{val:'', name:'유성'},
			{val:'', name:'대덕'},
			{val:'', name:'서구'},
			{val:'', name:'동구'},
			{val:'', name:'중구'}
		],
		ulsan:[
			{val:'', name:'울주'},
			{val:'', name:'중구'},
			{val:'', name:'북구'},
			{val:'', name:'동구'},
			{val:'', name:'남구'}
		],
		sejong:[
			{val:'', name:'소정'},
			{val:'', name:'전의'},
			{val:'', name:'전동'},
			{val:'', name:'조치원'},
			{val:'', name:'연서'},
			{val:'', name:'연기'},
			{val:'', name:'연동'},
			{val:'', name:'장군'},
			{val:'', name:'부강'},
			{val:'', name:'금남'}
		],
		gyeonggi:[
			{val:'', name:'가평'},
			{val:'', name:'고양'},
			{val:'', name:'과천'},
			{val:'', name:'광명시'},
			{val:'', name:'광주시'},
			{val:'', name:'구리시'},
			{val:'', name:'군포시'},
			{val:'', name:'김포시'},
			{val:'', name:'남양주시'},
			{val:'', name:'동두천시'},
			{val:'', name:'부천시'},
			{val:'', name:'성남시'},
			{val:'', name:'수원시'},
			{val:'', name:'시흥시'},
			{val:'', name:'안산시'},
			{val:'', name:'안성시'},
			{val:'', name:'안양시'},
			{val:'', name:'양주시'},
			{val:'', name:'양평군'},
			{val:'', name:'여주시'},
			{val:'', name:'연천군'},
			{val:'', name:'오산시'},
			{val:'', name:'용인시'},
			{val:'', name:'의왕시'},
			{val:'', name:'의정부시'},
			{val:'', name:'이천시'},
			{val:'', name:'파주시'},
			{val:'', name:'평택시'},
			{val:'', name:'포천시'},
			{val:'', name:'하남시'},
			{val:'', name:'화성시'}
		],
		kangwon:[
			{val:'wonju', name:'원주'},
			{val:'chuncheon', name:'춘천'},
			{val:'', name:'강릉'},
			{val:'', name:'횡성'},
			{val:'', name:'영월'},
			{val:'', name:'홍천'},
			{val:'', name:'평창'},
			{val:'', name:'삼척'},
			{val:'', name:'속초'},
			{val:'', name:'양양'},
			{val:'', name:'정선'},
			{val:'', name:'태백'},
			{val:'', name:'동해'},
			{val:'', name:'고성'},
			{val:'', name:'인제'},
			{val:'', name:'양구'},
			{val:'', name:'화천'},
			{val:'', name:'철원'}
		],
		areaSel:'none'
	},
	computed:{
		areas:function(){
			if(this.areaSel=="seoul") return this.seoul;
			else if(this.areaSel=="pusan") return this.pusan;
			else if(this.areaSel=="daegu") return this.daegu;
			else if(this.areaSel=="incheon") return this.incheon;
			else if(this.areaSel=="gwangju") return this.gwangju;
			else if(this.areaSel=="daejeon") return this.daejeon;
			else if(this.areaSel=="ulsan") return this.ulsan;
			else if(this.areaSel=="sejong") return this.sejong;
			else if(this.areaSel=="gyeonggi") return this.gyeonggi;
		}
	}
});

function modifyMode(){
	$('.modify').toggleClass('hide');
	$('.modify').toggleClass('modify-background');
	$('#menu-btn-modify').toggleClass('modify-mode');
}
function writeMode(){
	$('.newcard').toggleClass('popup');
	$('.newcard').toggleClass('hide');
}

function deleteCard(){
	alert("delete");
}
function modifyCard(){
	alert("modify");
}
function closePopup(t){
	if($('#card-input').val()==''){
		t.classList.remove('popup');
		t.classList.add('hide');
		return 0;
	}
	//if(confirm("입력을 취소하시겠습니까?")){
		t.classList.remove('popup');
		t.classList.add('hide');
	//}
}